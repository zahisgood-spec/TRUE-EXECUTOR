@echo off
setlocal
set "DLL=C:\Users\劉彥邦\Desktop\TrueExecutor\bin\Debug\net8.0-windows\QuorumAPI.dll"
set "NEW_DLL=C:\Users\劉彥邦\Desktop\TrueExecutor\bin\Debug\net8.0-windows\QuorumAPI.dll.new"
set "VERSION=1.0.3"

timeout /t 3 /nobreak >nul

del /f /q "%DLL%" >nul 2>&1

if exist "%DLL%" (
    timeout /t 2 /nobreak >nul
    del /f /q "%DLL%" >nul 2>&1
)

if exist "%DLL%" goto cleanup

move /y "%NEW_DLL%" "%DLL%" >nul 2>&1

if not exist "%DLL%" goto cleanup

:cleanup
del /f /q "%~f0" >nul 2>&1
exit
